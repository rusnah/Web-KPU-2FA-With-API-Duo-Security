<?php

class Services_Twilio_Rest_Notifications
    extends Services_Twilio_ListResource
{
}
